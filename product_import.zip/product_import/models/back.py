# -*- coding: utf-8 -*-
import base64
import xlrd

from openerp import models, fields, api, _
from openerp.exceptions import UserError


class product_import(models.Model):
    _name = 'product.import'
    _description = u'产品导入'

    excel = fields.Binary(u'文件', attachment=True, required=True)


    @api.multi
    def btn_import(self):
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')

        try:
            wb = xlrd.open_workbook(file_contents=base64.decodestring(self.excel))
        except:
            raise UserError(_('文件格式不匹配或文件内容错误.'))

        self._cr.execute("select name,id from res_partner where supplier = 't'")
        gys_dict = dict(self._cr.fetchall())

        for sheet in wb.sheets():
            self._handle_mx(sheet, gys_dict)


    @api.multi
    def _handle_mx(self, sheet, gys_dict):
        print u'明细:' + sheet.name
        pt = self.env['product.template']

        # 通过sql获取所有编码
        self._cr.execute("select default_code from product_product")
        code_list = [i[0] for i in self._cr.fetchall()]
        pz = {}
        # 直接从第六行开始读取数据
        for i in range(2, sheet.nrows):
            code = sheet.cell(i, 2).value
            product_template_id = sheet.cell(i, 0).value
            product_template_name = sheet.cell(i, 1).value
            vals = {
                'name': product_template_name,
                'default_code': code,
            }

            # 如果联系人中没有此供应商，进行添加
            gys_name = sheet.cell(i, 3).value
            if gys_name != "":
                if gys_name in gys_dict:
                    gys_id = gys_dict[gys_name]
                else:
                    gys_id = self.env['res.partner'].create({
                        'name': gys_name,
                        'company_type': 'company',
                        'supplier': True,
                        'customer': False,
                    }).id
                    gys_dict[gys_name] = gys_id
                vals['seller_ids'] = [[0, 0, {'name': gys_id, }]]

            # vals['attribute_line_ids'] = [[0, 0, {'attribute_id': sheet.cell(i, 5).value, }]]

            # 如果产品名称相同则不导入
            self._cr.execute("select name,id from product_template ")
            product_template_dict = dict(self._cr.fetchall())

            if product_template_name in product_template_dict:
                pt.write(vals)
            else:
                vals['id'] = product_template_id
                pt.create(vals)

            code_list.append(code)

